"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface User {
  id: string
  email: string
  name: string
  shop_name: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  loading: boolean
  connectionStatus: string
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [connectionStatus, setConnectionStatus] = useState("checking")

  useEffect(() => {
    // Timeout automatique après 4 secondes
    const maxTimeout = setTimeout(() => {
      console.log("⏰ Timeout de vérification atteint")
      setLoading(false)
      if (connectionStatus === "checking") {
        setConnectionStatus("disconnected")
      }
    }, 4000)

    // Vérification rapide
    const quickCheck = setTimeout(() => {
      checkConnection()
    }, 500)

    return () => {
      clearTimeout(maxTimeout)
      clearTimeout(quickCheck)
    }
  }, [])

  const checkConnection = async () => {
    try {
      console.log("🔍 Vérification rapide de la connexion backend...")

      // Timeout très court pour éviter le blocage
      const controller = new AbortController()
      const timeoutId = setTimeout(() => {
        controller.abort()
        console.log("⏰ Timeout de requête atteint")
      }, 2000) // 2 secondes max

      const response = await fetch("http://localhost:8000/", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (response.ok) {
        console.log("✅ Backend connecté")
        setConnectionStatus("connected")

        // Vérification rapide du token
        const token = localStorage.getItem("token")
        if (token) {
          console.log("🔑 Token trouvé, vérification rapide...")
          try {
            const userResponse = await fetch("http://localhost:8000/auth/me", {
              headers: { Authorization: `Bearer ${token}` },
              signal: controller.signal,
            })
            if (userResponse.ok) {
              const data = await userResponse.json()
              setUser(data.user)
              console.log("👤 Utilisateur connecté automatiquement")
            } else {
              localStorage.removeItem("token")
              console.log("🗑️ Token invalide, supprimé")
            }
          } catch (error) {
            localStorage.removeItem("token")
            console.log("❌ Erreur de vérification du token")
          }
        }
      } else {
        console.log("❌ Backend non accessible")
        setConnectionStatus("disconnected")
      }
    } catch (error) {
      if (error.name === "AbortError") {
        console.log("⏰ Requête annulée par timeout")
      } else {
        console.error("❌ Erreur de connexion au backend:", error)
      }
      setConnectionStatus("disconnected")
    } finally {
      setLoading(false)
      console.log("✅ Vérification terminée")
    }
  }

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      console.log("🔐 Tentative de connexion avec:", { email, password })

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 5000) // 5 secondes max

      const response = await fetch("http://localhost:8000/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
        signal: controller.signal,
      })

      clearTimeout(timeoutId)
      console.log("📡 Statut de la réponse:", response.status)

      if (response.ok) {
        const data = await response.json()
        console.log("✅ Données reçues:", data)

        localStorage.setItem("token", data.access_token)
        setUser(data.user)
        setConnectionStatus("connected")
        return true
      } else {
        let errorMessage = "Erreur de connexion"
        try {
          const errorData = await response.json()
          errorMessage = errorData.detail || errorMessage
          console.error("❌ Erreur de login:", errorData)
        } catch (e) {
          console.error("❌ Erreur de parsing:", e)
        }
        console.error("❌ Status:", response.status, response.statusText)
        return false
      }
    } catch (error) {
      console.error("❌ Erreur de connexion:", error)
      setConnectionStatus("disconnected")
      return false
    }
  }

  const logout = () => {
    localStorage.removeItem("token")
    setUser(null)
    setConnectionStatus("connected")
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, connectionStatus }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
