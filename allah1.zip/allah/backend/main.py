from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import uvicorn
from datetime import datetime, timedelta
from jose import jwt, JWTError  # Utiliser jose au lieu de jwt direct
import bcrypt
import os
from typing import Optional, List

# Configuration
app = FastAPI(title="Agent WhatsApp IA API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Sécurité
security = HTTPBearer()
SECRET_KEY = "your-secret-key-change-this"
ALGORITHM = "HS256"

# Base de données simple en mémoire pour les tests
users_db = {
    "admin@test.com": {
        "id": "1",
        "email": "admin@test.com",
        "name": "Admin Test",
        "shop_name": "Ma Boutique Test",
        "hashed_password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBVJ3/7Wk6Hp7."  # 123456
    }
}

products_db = [
    {
        "id": 1,
        "user_id": "1",
        "name": "T-shirt Blanc",
        "price": 150.0,
        "description": "T-shirt en coton blanc de qualité",
        "size": "M",
        "category": "Vêtements",
        "is_active": True,
        "stock_quantity": 10,
        "image_url": "/placeholder.svg?height=100&width=100",
        "created_at": datetime.utcnow().isoformat()
    },
    {
        "id": 2,
        "user_id": "1",
        "name": "Jean Bleu",
        "price": 280.0,
        "description": "Jean slim fit bleu",
        "size": "32",
        "category": "Vêtements",
        "is_active": True,
        "stock_quantity": 5,
        "image_url": "/placeholder.svg?height=100&width=100",
        "created_at": datetime.utcnow().isoformat()
    }
]

orders_db = [
    {
        "id": 1,
        "user_id": "1",
        "order_id": "1024",
        "client_name": "Ahmed Benali",
        "client_phone": "+212600123456",
        "client_address": "123 Rue Mohammed V, Casablanca",
        "city": "Casablanca",
        "status": "en_attente",
        "total_amount": 150.0,
        "delivery_fee": 30.0,
        "notes": "Livraison rapide demandée",
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat()
    }
]

messages_db = [
    {
        "id": 1,
        "user_id": "1",
        "phone": "+212600123456",
        "message": "Bonjour, avez-vous des t-shirts en stock ?",
        "ai_response": "Bonjour ! Oui, nous avons des t-shirts en stock. Nous avons notamment un t-shirt blanc en coton de qualité à 150 DH. Quelle taille vous intéresse ?",
        "message_type": "text",
        "intent": "produit",
        "is_spam": False,
        "timestamp": datetime.utcnow().isoformat()
    }
]

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Token invalide")
        return user_id
    except JWTError:
        raise HTTPException(status_code=401, detail="Token invalide")

@app.post("/auth/login")
async def login(credentials: dict):
    email = credentials.get("email")
    password = credentials.get("password")
    
    user = users_db.get(email)
    if not user or not bcrypt.checkpw(password.encode('utf-8'), user["hashed_password"].encode('utf-8')):
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    
    access_token = create_access_token(data={"sub": user["id"]})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "email": user["email"],
            "name": user["name"],
            "shop_name": user["shop_name"]
        }
    }

@app.get("/auth/me")
async def get_current_user(user_id: str = Depends(verify_token)):
    for user in users_db.values():
        if user["id"] == user_id:
            return {
                "user": {
                    "id": user["id"],
                    "email": user["email"],
                    "name": user["name"],
                    "shop_name": user["shop_name"]
                }
            }
    raise HTTPException(status_code=404, detail="Utilisateur non trouvé")

@app.get("/products")
async def get_products(user_id: str = Depends(verify_token)):
    return [p for p in products_db if p.get("user_id") == user_id]

@app.post("/products")
async def create_product(product: dict, user_id: str = Depends(verify_token)):
    new_product = {
        "id": len(products_db) + 1,
        "user_id": user_id,
        "created_at": datetime.utcnow().isoformat(),
        "is_active": True,
        **product
    }
    products_db.append(new_product)
    return new_product

@app.put("/products/{product_id}")
async def update_product(product_id: int, product: dict, user_id: str = Depends(verify_token)):
    for i, p in enumerate(products_db):
        if p["id"] == product_id and p["user_id"] == user_id:
            products_db[i].update(product)
            return products_db[i]
    raise HTTPException(status_code=404, detail="Produit non trouvé")

@app.delete("/products/{product_id}")
async def delete_product(product_id: int, user_id: str = Depends(verify_token)):
    for i, p in enumerate(products_db):
        if p["id"] == product_id and p["user_id"] == user_id:
            products_db.pop(i)
            return {"message": "Produit supprimé"}
    raise HTTPException(status_code=404, detail="Produit non trouvé")

@app.get("/orders")
async def get_orders(user_id: str = Depends(verify_token)):
    return [o for o in orders_db if o.get("user_id") == user_id]

@app.post("/orders")
async def create_order(order: dict, user_id: str = Depends(verify_token)):
    new_order = {
        "id": len(orders_db) + 1,
        "user_id": user_id,
        "order_id": f"10{len(orders_db) + 24}",
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat(),
        **order
    }
    orders_db.append(new_order)
    return new_order

@app.get("/messages")
async def get_messages(user_id: str = Depends(verify_token)):
    return [m for m in messages_db if m.get("user_id") == user_id]

@app.post("/messages/send")
async def send_message(data: dict, user_id: str = Depends(verify_token)):
    phone = data.get("phone")
    message = data.get("message")
    
    new_message = {
        "id": len(messages_db) + 1,
        "user_id": user_id,
        "phone": phone,
        "message": message,
        "ai_response": None,
        "message_type": "text",
        "intent": "general",
        "is_spam": False,
        "timestamp": datetime.utcnow().isoformat()
    }
    messages_db.append(new_message)
    return {"success": True, "message": "Message envoyé"}

@app.get("/whatsapp/status")
async def whatsapp_status(user_id: str = Depends(verify_token)):
    return {"status": "disconnected"}

@app.post("/whatsapp/connect")
async def connect_whatsapp(user_id: str = Depends(verify_token)):
    # QR Code de test (image 1x1 pixel transparent)
    qr_code = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
    return {"qr_code": qr_code}

@app.delete("/whatsapp/disconnect")
async def disconnect_whatsapp(user_id: str = Depends(verify_token)):
    return {"message": "WhatsApp déconnecté"}

@app.get("/stats/dashboard")
async def get_dashboard_stats(user_id: str = Depends(verify_token)):
    user_products = [p for p in products_db if p.get("user_id") == user_id]
    user_orders = [o for o in orders_db if o.get("user_id") == user_id]
    user_messages = [m for m in messages_db if m.get("user_id") == user_id]
    
    return {
        "total_orders": len(user_orders),
        "pending_orders": len([o for o in user_orders if o.get("status") == "en_attente"]),
        "total_messages": len(user_messages),
        "total_products": len(user_products)
    }

@app.post("/ai/test-message")
async def test_ai_message(data: dict, user_id: str = Depends(verify_token)):
    message = data.get("message", "")
    
    # Simulation de réponse IA simple
    if "produit" in message.lower() or "stock" in message.lower():
        response = "Nous avons plusieurs produits en stock. Que recherchez-vous exactement ?"
    elif "commande" in message.lower():
        response = "Je peux vous aider à passer une commande. Quel produit vous intéresse ?"
    elif "prix" in message.lower():
        response = "Nos prix varient selon les produits. Pouvez-vous me dire quel article vous intéresse ?"
    else:
        response = f"Merci pour votre message : '{message}'. Comment puis-je vous aider ?"
    
    return {"ai_response": response}

@app.get("/ai/analytics")
async def get_ai_analytics(user_id: str = Depends(verify_token)):
    user_messages = [m for m in messages_db if m.get("user_id") == user_id]
    
    return {
        "total_messages": len(user_messages),
        "ai_responses": len([m for m in user_messages if m.get("ai_response")]),
        "intents_detected": {
            "produit": len([m for m in user_messages if m.get("intent") == "produit"]),
            "commande": len([m for m in user_messages if m.get("intent") == "commande"]),
            "suivi": len([m for m in user_messages if m.get("intent") == "suivi"]),
            "general": len([m for m in user_messages if m.get("intent") == "general"])
        },
        "response_time_avg": 1200
    }

# Route de test pour vérifier que l'API fonctionne
@app.get("/")
async def root():
    return {
        "message": "Agent WhatsApp IA API",
        "status": "✅ Fonctionnel",
        "version": "1.0.0",
        "endpoints": {
            "login": "/auth/login",
            "products": "/products",
            "orders": "/orders",
            "messages": "/messages",
            "whatsapp": "/whatsapp/status",
            "docs": "/docs"
        }
    }

if __name__ == "__main__":
    print("🚀 Démarrage du serveur Agent WhatsApp IA...")
    print("📱 API disponible sur: http://localhost:8000")
    print("📚 Documentation: http://localhost:8000/docs")
    print("🔐 Identifiants de test: admin@test.com / 123456")
    print("✅ Serveur prêt !")
    uvicorn.run(app, host="0.0.0.0", port=8000)
