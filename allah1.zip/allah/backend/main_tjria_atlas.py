from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from jose import jwt, JWTError
import bcrypt
import uvicorn
import os
from typing import Optional, List
import uuid

# Configuration MongoDB Atlas (Cloud)
try:
    from pymongo import MongoClient
    from bson import ObjectId
    
    # URL MongoDB Atlas - Remplacez par votre URL
    MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://username:password@cluster.mongodb.net/tjria?retryWrites=true&w=majority")
    
    # Si pas d'URL Atlas, utiliser une base locale simple
    if "mongodb+srv" not in MONGO_URL:
        # Essayer MongoDB local d'abord
        try:
            client = MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=3000)
            client.admin.command('ping')
            print("✅ MongoDB local connecté !")
        except:
            # Si échec, utiliser une base de données fichier simple
            print("⚠️ MongoDB local non disponible, utilisation d'une base fichier...")
            import json
            import os
            
            DB_FILE = "tjria_database.json"
            
            def load_db():
                if os.path.exists(DB_FILE):
                    with open(DB_FILE, 'r', encoding='utf-8') as f:
                        return json.load(f)
                return {"users": [], "products": [], "orders": [], "messages": []}
            
            def save_db(data):
                with open(DB_FILE, 'w', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            
            # Base de données fichier
            db_data = load_db()
            MONGODB_AVAILABLE = False
            FILE_DB = True
    else:
        client = MongoClient(MONGO_URL)
        client.admin.command('ping')
        print("✅ MongoDB Atlas connecté !")
        MONGODB_AVAILABLE = True
        FILE_DB = False
    
    if MONGODB_AVAILABLE:
        db = client.tjria_db
        users_collection = db.users
        products_collection = db.products
        orders_collection = db.orders
        messages_collection = db.messages
    
except Exception as e:
    print(f"⚠️ MongoDB non disponible: {e}")
    print("🔄 Utilisation d'une base de données fichier...")
    
    import json
    import os
    
    DB_FILE = "tjria_database.json"
    MONGODB_AVAILABLE = False
    FILE_DB = True
    
    def load_db():
        if os.path.exists(DB_FILE):
            with open(DB_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"users": [], "products": [], "orders": [], "messages": []}
    
    def save_db(data):
        with open(DB_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
    
    db_data = load_db()

# Configuration FastAPI
app = FastAPI(title="TJRIA - Agent WhatsApp IA", version="2.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Sécurité
security = HTTPBearer()
SECRET_KEY = "tjria-secret-key-2025"
ALGORITHM = "HS256"

# Schémas Pydantic (même que avant)
class UserCreate(BaseModel):
    email: EmailStr
    name: str
    phone: str
    password: str
    shop_name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class ProductCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    size: Optional[str] = None
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: Optional[int] = 0

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    size: Optional[str] = None
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: Optional[int] = None

# Fonctions utilitaires
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Token invalide")
        return user_id
    except JWTError:
        raise HTTPException(status_code=401, detail="Token invalide")

def get_current_user(user_id: str = Depends(verify_token)):
    if user_id == "demo":
        return {
            "_id": "demo",
            "email": "admin@tjria.com",
            "name": "Admin TJRIA",
            "shop_name": "TJRIA Store"
        }
    
    if MONGODB_AVAILABLE:
        user = users_collection.find_one({"_id": ObjectId(user_id)})
        if user is None:
            raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
        return user
    else:
        # Base fichier
        for user in db_data["users"]:
            if user["id"] == user_id:
                return user
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")

# Routes d'authentification
@app.post("/auth/login")
async def login(credentials: UserLogin):
    print(f"🔐 Tentative de connexion TJRIA: {credentials.email}")
    
    # Utilisateur de démonstration
    if credentials.email == "admin@tjria.com" and credentials.password == "123456":
        access_token = create_access_token(data={"sub": "demo"})
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": "demo",
                "email": "admin@tjria.com",
                "name": "Admin TJRIA",
                "shop_name": "TJRIA Store"
            }
        }
    
    raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")

# Routes des produits avec base fichier
@app.get("/products")
async def get_products(current_user: dict = Depends(get_current_user)):
    print(f"📦 Récupération des produits pour: {current_user['email']}")
    
    # Produits de démonstration
    demo_products = [
        {
            "id": "1",
            "name": "T-shirt TJRIA Premium",
            "description": "T-shirt de qualité supérieure avec logo TJRIA",
            "price": 150.0,
            "size": "M, L, XL",
            "category": "Vêtements",
            "image_url": "/placeholder.svg?height=200&width=200",
            "stock_quantity": 25,
            "is_active": True,
            "created_at": datetime.utcnow().isoformat()
        },
        {
            "id": "2",
            "name": "Casquette TJRIA",
            "description": "Casquette ajustable avec broderie TJRIA",
            "price": 80.0,
            "size": "Unique",
            "category": "Accessoires",
            "image_url": "/placeholder.svg?height=200&width=200",
            "stock_quantity": 15,
            "is_active": True,
            "created_at": datetime.utcnow().isoformat()
        },
        {
            "id": "3",
            "name": "Sweat TJRIA",
            "description": "Sweat-shirt confortable pour toutes saisons",
            "price": 220.0,
            "size": "S, M, L, XL",
            "category": "Vêtements",
            "image_url": "/placeholder.svg?height=200&width=200",
            "stock_quantity": 12,
            "is_active": True,
            "created_at": datetime.utcnow().isoformat()
        }
    ]
    
    if not MONGODB_AVAILABLE:
        # Ajouter les produits de la base fichier
        user_id = current_user.get("id", "demo")
        user_products = [p for p in db_data["products"] if p.get("user_id") == user_id]
        return demo_products + user_products
    
    return demo_products

@app.post("/products")
async def create_product(product: ProductCreate, current_user: dict = Depends(get_current_user)):
    print(f"➕ Création d'un produit: {product.name}")
    
    user_id = current_user.get("_id") or current_user.get("id", "demo")
    product_id = str(uuid.uuid4())
    
    product_doc = {
        "id": product_id,
        **product.model_dump(),
        "user_id": user_id,
        "is_active": True,
        "created_at": datetime.utcnow().isoformat()
    }
    
    if MONGODB_AVAILABLE:
        result = products_collection.insert_one(product_doc)
        product_doc["_id"] = result.inserted_id
    else:
        # Sauvegarder dans le fichier
        db_data["products"].append(product_doc)
        save_db(db_data)
        print(f"💾 Produit sauvegardé dans tjria_database.json")
    
    return product_doc

@app.delete("/products/{product_id}")
async def delete_product(product_id: str, current_user: dict = Depends(get_current_user)):
    print(f"🗑️ Suppression du produit: {product_id}")
    
    user_id = current_user.get("_id") or current_user.get("id", "demo")
    
    if MONGODB_AVAILABLE:
        result = products_collection.delete_one(
            {"_id": ObjectId(product_id), "user_id": user_id}
        )
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Produit non trouvé")
    else:
        # Supprimer du fichier
        for i, p in enumerate(db_data["products"]):
            if p["id"] == product_id and p["user_id"] == user_id:
                db_data["products"].pop(i)
                save_db(db_data)
                print(f"💾 Produit supprimé de tjria_database.json")
                break
        else:
            raise HTTPException(status_code=404, detail="Produit non trouvé")
    
    return {"message": "Produit supprimé avec succès"}

# Routes des commandes, messages, etc. (similaires)
@app.get("/orders")
async def get_orders(current_user: dict = Depends(get_current_user)):
    demo_orders = [
        {
            "id": "1",
            "order_id": "TJR20250530001",
            "client_name": "Ahmed Benali",
            "client_phone": "+212600123456",
            "status": "en_attente",
            "total_amount": 150.0,
            "created_at": datetime.utcnow().isoformat()
        }
    ]
    return demo_orders

@app.get("/messages")
async def get_messages(current_user: dict = Depends(get_current_user)):
    demo_messages = [
        {
            "id": "1",
            "phone": "+212600123456",
            "message": "Bonjour, avez-vous des t-shirts en stock ?",
            "ai_response": "Bonjour ! Oui, nous avons des t-shirts TJRIA Premium en stock.",
            "timestamp": datetime.utcnow().isoformat()
        }
    ]
    return demo_messages

@app.get("/whatsapp/status")
async def whatsapp_status(current_user: dict = Depends(get_current_user)):
    return {"status": "disconnected", "message": "Cliquez sur 'Connecter' pour scanner le QR code"}

@app.get("/stats/dashboard")
async def get_dashboard_stats(current_user: dict = Depends(get_current_user)):
    return {
        "total_orders": 3,
        "pending_orders": 1,
        "total_messages": 2,
        "total_products": 3,
        "total_revenue": 670.0
    }

@app.get("/ai/analytics")
async def get_ai_analytics(current_user: dict = Depends(get_current_user)):
    return {
        "total_messages": 2,
        "ai_responses": 2,
        "response_time_avg": 850,
        "accuracy_rate": 95.5
    }

@app.post("/ai/test-message")
async def test_ai_message(data: dict, current_user: dict = Depends(get_current_user)):
    message = data.get("message", "")
    return {
        "ai_response": f"Merci de contacter TJRIA ! Votre message: '{message}' a été bien reçu.",
        "intent": "general",
        "confidence": 0.95
    }

@app.get("/")
async def root():
    db_status = "MongoDB" if MONGODB_AVAILABLE else "Fichier JSON (tjria_database.json)"
    return {
        "message": "✅ TJRIA - Agent WhatsApp IA Professionnel",
        "status": "running",
        "database": db_status,
        "file_db": not MONGODB_AVAILABLE,
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    print("🚀 Démarrage de TJRIA - Agent WhatsApp IA Professionnel")
    print("📱 API disponible sur: http://localhost:8000")
    print("🔐 Identifiants: admin@tjria.com / 123456")
    
    if MONGODB_AVAILABLE:
        print("🗄️ Base de données: MongoDB")
    else:
        print("🗄️ Base de données: Fichier JSON (tjria_database.json)")
        print("💾 Les données seront sauvegardées dans un fichier")
    
    print("✅ TJRIA prêt !")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
