from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
from datetime import datetime
import json

app = FastAPI(title="Agent WhatsApp IA API")

# Configuration CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modèle Pydantic pour validation
class LoginCredentials(BaseModel):
    email: str
    password: str

# Données de test
user_data = {
    "id": "1",
    "email": "admin@test.com",
    "name": "Admin Test",
    "shop_name": "Ma Boutique Test"
}

@app.get("/")
async def root():
    return {
        "message": "✅ API Agent WhatsApp IA - Fonctionnel !",
        "status": "running",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/auth/login")
async def login(credentials: LoginCredentials):
    print("=" * 50)
    print(f"🔐 NOUVELLE TENTATIVE DE CONNEXION")
    print(f"📨 Données reçues:")
    print(f"   📧 Email: '{credentials.email}'")
    print(f"   🔒 Password: '{credentials.password}'")
    
    # Vérification
    email_match = credentials.email == "admin@test.com"
    password_match = credentials.password == "123456"
    
    print(f"🔍 Email match: {email_match}")
    print(f"🔍 Password match: {password_match}")
    
    if email_match and password_match:
        response = {
            "access_token": "test-token-123",
            "token_type": "bearer",
            "user": user_data
        }
        print(f"✅ CONNEXION RÉUSSIE!")
        print("=" * 50)
        return response
    else:
        print(f"❌ ÉCHEC DE CONNEXION")
        print("=" * 50)
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")

@app.get("/auth/me")
async def get_current_user():
    return {"user": user_data}

@app.get("/products")
async def get_products():
    return [
        {
            "id": 1,
            "name": "T-shirt Blanc",
            "price": 150.0,
            "description": "T-shirt en coton",
            "size": "M",
            "category": "Vêtements",
            "is_active": True,
            "stock_quantity": 10,
            "created_at": datetime.utcnow().isoformat()
        },
        {
            "id": 2,
            "name": "Jean Bleu",
            "price": 280.0,
            "description": "Jean slim fit",
            "size": "32",
            "category": "Vêtements",
            "is_active": True,
            "stock_quantity": 5,
            "created_at": datetime.utcnow().isoformat()
        }
    ]

@app.post("/products")
async def create_product(product: dict):
    new_product = {
        "id": 3,
        "name": product.get("name", "Nouveau produit"),
        "price": float(product.get("price", 0)),
        "description": product.get("description", ""),
        "size": product.get("size", ""),
        "category": product.get("category", ""),
        "is_active": True,
        "stock_quantity": int(product.get("stock_quantity", 0)),
        "created_at": datetime.utcnow().isoformat()
    }
    return new_product

@app.get("/orders")
async def get_orders():
    return [
        {
            "id": 1,
            "order_id": "1024",
            "client_name": "Ahmed Benali",
            "client_phone": "+212600123456",
            "client_address": "123 Rue Mohammed V, Casablanca",
            "city": "Casablanca",
            "status": "en_attente",
            "total_amount": 150.0,
            "delivery_fee": 30.0,
            "created_at": datetime.utcnow().isoformat()
        },
        {
            "id": 2,
            "order_id": "1025",
            "client_name": "Fatima Zahra",
            "client_phone": "+212600987654",
            "client_address": "456 Avenue Hassan II, Rabat",
            "city": "Rabat",
            "status": "en_livraison",
            "total_amount": 280.0,
            "delivery_fee": 25.0,
            "created_at": datetime.utcnow().isoformat()
        }
    ]

@app.get("/messages")
async def get_messages():
    return [
        {
            "id": 1,
            "phone": "+212600123456",
            "message": "Bonjour, avez-vous des t-shirts en stock ?",
            "ai_response": "Bonjour ! Oui, nous avons des t-shirts en stock. Nous avons notamment un t-shirt blanc en coton de qualité à 150 DH. Quelle taille vous intéresse ?",
            "message_type": "text",
            "intent": "produit",
            "is_spam": False,
            "timestamp": datetime.utcnow().isoformat()
        },
        {
            "id": 2,
            "phone": "+212600987654",
            "message": "Je veux commander un jean",
            "ai_response": "Parfait ! Nous avons un jean bleu slim fit à 280 DH en taille 32. Souhaitez-vous passer commande ?",
            "message_type": "text",
            "intent": "commande",
            "is_spam": False,
            "timestamp": datetime.utcnow().isoformat()
        }
    ]

@app.get("/whatsapp/status")
async def whatsapp_status():
    return {"status": "disconnected"}

@app.post("/whatsapp/connect")
async def connect_whatsapp():
    return {"qr_code": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="}

@app.get("/stats/dashboard")
async def get_dashboard_stats():
    return {
        "total_orders": 2,
        "pending_orders": 1,
        "total_messages": 2,
        "total_products": 2
    }

@app.get("/ai/analytics")
async def get_ai_analytics():
    return {
        "total_messages": 24,
        "ai_responses": 18,
        "intents_detected": {
            "produit": 10,
            "commande": 5,
            "suivi": 3,
            "general": 6
        },
        "response_time_avg": 1200
    }

@app.post("/ai/test-message")
async def test_ai_message(data: dict):
    message = data.get("message", "")
    
    if "produit" in message.lower() or "stock" in message.lower():
        response = "Nous avons plusieurs produits en stock. Que recherchez-vous exactement ?"
    elif "commande" in message.lower():
        response = "Je peux vous aider à passer une commande. Quel produit vous intéresse ?"
    elif "prix" in message.lower():
        response = "Nos prix varient selon les produits. Pouvez-vous me dire quel article vous intéresse ?"
    else:
        response = f"Merci pour votre message : '{message}'. Comment puis-je vous aider ?"
    
    return {"ai_response": response}

if __name__ == "__main__":
    print("🚀 Démarrage du serveur Agent WhatsApp IA...")
    print("📱 API disponible sur: http://localhost:8000")
    print("📚 Documentation: http://localhost:8000/docs")
    print("🔐 Identifiants:")
    print("   📧 Email: admin@test.com")
    print("   🔒 Password: 123456")
    print("✅ Serveur stable prêt !")
    print("⚠️  NE FERMEZ PAS CETTE FENÊTRE !")
    
    # Sans reload pour plus de stabilité
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
