from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from datetime import datetime
import json
from pydantic import BaseModel

app = FastAPI(title="Agent WhatsApp IA API")

# Configuration CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modèle Pydantic pour les données de login
class LoginRequest(BaseModel):
    email: str
    password: str

# Données de test (en mémoire, pas de base de données)
user_data = {
    "id": "1",
    "email": "admin@test.com",
    "name": "Admin Test",
    "shop_name": "Ma Boutique Test"
}

@app.get("/")
async def root():
    return {
        "message": "✅ API Agent WhatsApp IA - Fonctionnel !",
        "status": "running",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/auth/login")
async def login(request: LoginRequest):
    print("=" * 50)
    print(f"🔐 NOUVELLE TENTATIVE DE CONNEXION")
    print(f"📨 Données reçues via Pydantic:")
    print(f"   📧 Email: '{request.email}'")
    print(f"   🔒 Password: '{request.password}'")
    
    # Vérification avec debug
    email_match = request.email == "admin@test.com"
    password_match = request.password == "123456"
    
    print(f"🔍 Email match: {email_match}")
    print(f"🔍 Password match: {password_match}")
    
    if email_match and password_match:
        response = {
            "access_token": "test-token-123",
            "token_type": "bearer",
            "user": user_data
        }
        print(f"✅ CONNEXION RÉUSSIE!")
        print(f"📤 Réponse envoyée: {json.dumps(response, indent=2)}")
        print("=" * 50)
        return response
    else:
        print(f"❌ ÉCHEC DE CONNEXION")
        print(f"❌ Raison: Email={email_match}, Password={password_match}")
        print("=" * 50)
        raise HTTPException(
            status_code=401, 
            detail="Email ou mot de passe incorrect"
        )

# Alternative avec Request raw pour debug
@app.post("/auth/login-debug")
async def login_debug(request: Request):
    print("=" * 50)
    print(f"🐛 DEBUG LOGIN - Headers:")
    for name, value in request.headers.items():
        print(f"   {name}: {value}")
    
    body = await request.body()
    print(f"🐛 DEBUG LOGIN - Body raw: {body}")
    
    try:
        json_data = await request.json()
        print(f"🐛 DEBUG LOGIN - JSON parsed: {json_data}")
        return {"received": json_data}
    except Exception as e:
        print(f"🐛 DEBUG LOGIN - Erreur parsing JSON: {e}")
        return {"error": str(e), "body": body.decode()}

@app.get("/auth/me")
async def get_current_user():
    return {"user": user_data}

@app.get("/products")
async def get_products():
    return [
        {
            "id": 1,
            "name": "T-shirt Blanc",
            "price": 150.0,
            "description": "T-shirt en coton",
            "size": "M",
            "category": "Vêtements",
            "is_active": True,
            "stock_quantity": 10,
            "created_at": datetime.utcnow().isoformat()
        }
    ]

@app.get("/orders")
async def get_orders():
    return [
        {
            "id": 1,
            "order_id": "1024",
            "client_name": "Ahmed Benali",
            "client_phone": "+212600123456",
            "status": "en_attente",
            "total_amount": 150.0,
            "created_at": datetime.utcnow().isoformat()
        }
    ]

@app.get("/messages")
async def get_messages():
    return [
        {
            "id": 1,
            "phone": "+212600123456",
            "message": "Bonjour !",
            "ai_response": "Bonjour ! Comment puis-je vous aider ?",
            "timestamp": datetime.utcnow().isoformat()
        }
    ]

@app.get("/whatsapp/status")
async def whatsapp_status():
    return {"status": "disconnected"}

@app.get("/stats/dashboard")
async def get_dashboard_stats():
    return {
        "total_orders": 1,
        "pending_orders": 1,
        "total_messages": 1,
        "total_products": 1
    }

if __name__ == "__main__":
    print("🚀 Démarrage du serveur Agent WhatsApp IA...")
    print("📱 API disponible sur: http://localhost:8000")
    print("🔐 Identifiants EXACTS:")
    print("   📧 Email: admin@test.com")
    print("   🔒 Password: 123456")
    print("🗄️ AUCUNE BASE DE DONNÉES - Tout en mémoire pour les tests")
    print("🐛 Mode debug activé")
    print("✅ Serveur prêt !")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
