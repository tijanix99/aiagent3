from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from jose import jwt, JWTError
import bcrypt
import uvicorn
import os
from typing import Optional, List
import uuid
import json

# Tentative de connexion MongoDB (optionnelle)
try:
    from pymongo import MongoClient
    from bson import ObjectId
    
    MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017/")
    client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=3000)  # 3 secondes timeout
    # Test de connexion
    client.admin.command('ping')
    db = client.whatsapp_agent_db
    
    # Collections MongoDB
    users_collection = db.users
    products_collection = db.products
    orders_collection = db.orders
    messages_collection = db.messages
    
    MONGODB_AVAILABLE = True
    print("✅ MongoDB connecté avec succès !")
    
except Exception as e:
    print(f"⚠️ MongoDB non disponible: {e}")
    print("🔄 Basculement vers le mode mémoire...")
    MONGODB_AVAILABLE = False
    
    # Données en mémoire comme fallback
    memory_users = []
    memory_products = []
    memory_orders = []
    memory_messages = []

# Configuration FastAPI
app = FastAPI(title="TJRIA - Agent WhatsApp IA", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Sécurité
security = HTTPBearer()
SECRET_KEY = "tjria-secret-key-2025"
ALGORITHM = "HS256"

# Schémas Pydantic
class UserCreate(BaseModel):
    email: EmailStr
    name: str
    phone: str
    password: str
    shop_name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class ProductCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    size: Optional[str] = None
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: Optional[int] = 0

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    size: Optional[str] = None
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: Optional[int] = None

class OrderCreate(BaseModel):
    client_name: str
    client_phone: str
    client_address: Optional[str] = None
    city: Optional[str] = None
    total_amount: float
    delivery_fee: Optional[float] = 0
    notes: Optional[str] = None

# Fonctions utilitaires
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Token invalide")
        return user_id
    except JWTError:
        raise HTTPException(status_code=401, detail="Token invalide")

def get_current_user(user_id: str = Depends(verify_token)):
    if user_id == "demo":
        return {
            "_id": "demo",
            "email": "admin@tjria.com",
            "name": "Admin TJRIA",
            "shop_name": "TJRIA Store"
        }
    
    if MONGODB_AVAILABLE:
        user = users_collection.find_one({"_id": ObjectId(user_id)})
        if user is None:
            raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
        return user
    else:
        # Mode mémoire
        for user in memory_users:
            if user["id"] == user_id:
                return user
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")

def serialize_mongo_doc(doc):
    """Convertit les ObjectId MongoDB en strings"""
    if doc is None:
        return None
    if isinstance(doc, list):
        return [serialize_mongo_doc(item) for item in doc]
    if isinstance(doc, dict):
        result = {}
        for key, value in doc.items():
            if key == "_id":
                result["id"] = str(value)
            elif isinstance(value, ObjectId):
                result[key] = str(value)
            elif isinstance(value, datetime):
                result[key] = value.isoformat()
            else:
                result[key] = value
        return result
    return doc

# Routes d'authentification
@app.post("/auth/register")
async def register(user: UserCreate):
    print(f"🔐 Inscription TJRIA: {user.email}")
    
    if MONGODB_AVAILABLE:
        existing_user = users_collection.find_one({"email": user.email})
        if existing_user:
            raise HTTPException(status_code=400, detail="Email déjà utilisé")
        
        hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
        
        user_doc = {
            "email": user.email,
            "name": user.name,
            "phone": user.phone,
            "hashed_password": hashed_password.decode('utf-8'),
            "shop_name": user.shop_name,
            "is_active": True,
            "created_at": datetime.utcnow()
        }
        
        result = users_collection.insert_one(user_doc)
        return {"message": "Utilisateur créé avec succès", "user_id": str(result.inserted_id)}
    else:
        # Mode mémoire
        for existing_user in memory_users:
            if existing_user["email"] == user.email:
                raise HTTPException(status_code=400, detail="Email déjà utilisé")
        
        hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
        user_id = str(uuid.uuid4())
        
        user_doc = {
            "id": user_id,
            "email": user.email,
            "name": user.name,
            "phone": user.phone,
            "hashed_password": hashed_password.decode('utf-8'),
            "shop_name": user.shop_name,
            "is_active": True,
            "created_at": datetime.utcnow().isoformat()
        }
        
        memory_users.append(user_doc)
        return {"message": "Utilisateur créé avec succès", "user_id": user_id}

@app.post("/auth/login")
async def login(credentials: UserLogin):
    print(f"🔐 Tentative de connexion TJRIA: {credentials.email}")
    
    # Utilisateur de démonstration
    if credentials.email == "admin@tjria.com" and credentials.password == "123456":
        access_token = create_access_token(data={"sub": "demo"})
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": "demo",
                "email": "admin@tjria.com",
                "name": "Admin TJRIA",
                "shop_name": "TJRIA Store"
            }
        }
    
    if MONGODB_AVAILABLE:
        user = users_collection.find_one({"email": credentials.email})
        if not user or not bcrypt.checkpw(credentials.password.encode('utf-8'), user["hashed_password"].encode('utf-8')):
            raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
        
        access_token = create_access_token(data={"sub": str(user["_id"])})
        
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user["_id"]),
                "email": user["email"],
                "name": user["name"],
                "shop_name": user["shop_name"]
            }
        }
    else:
        # Mode mémoire
        for user in memory_users:
            if user["email"] == credentials.email:
                if bcrypt.checkpw(credentials.password.encode('utf-8'), user["hashed_password"].encode('utf-8')):
                    access_token = create_access_token(data={"sub": user["id"]})
                    return {
                        "access_token": access_token,
                        "token_type": "bearer",
                        "user": {
                            "id": user["id"],
                            "email": user["email"],
                            "name": user["name"],
                            "shop_name": user["shop_name"]
                        }
                    }
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")

# Routes des produits
@app.get("/products")
async def get_products(current_user: dict = Depends(get_current_user)):
    print(f"📦 Récupération des produits pour: {current_user['email']}")
    
    # Produits de démonstration pour l'utilisateur demo
    if current_user.get("_id") == "demo" or current_user.get("id") == "demo":
        demo_products = [
            {
                "id": "1",
                "name": "T-shirt TJRIA Premium",
                "description": "T-shirt de qualité supérieure avec logo TJRIA",
                "price": 150.0,
                "size": "M, L, XL",
                "category": "Vêtements",
                "image_url": "/placeholder.svg?height=200&width=200",
                "stock_quantity": 25,
                "is_active": True,
                "created_at": datetime.utcnow().isoformat()
            },
            {
                "id": "2",
                "name": "Casquette TJRIA",
                "description": "Casquette ajustable avec broderie TJRIA",
                "price": 80.0,
                "size": "Unique",
                "category": "Accessoires",
                "image_url": "/placeholder.svg?height=200&width=200",
                "stock_quantity": 15,
                "is_active": True,
                "created_at": datetime.utcnow().isoformat()
            },
            {
                "id": "3",
                "name": "Sweat TJRIA",
                "description": "Sweat-shirt confortable pour toutes saisons",
                "price": 220.0,
                "size": "S, M, L, XL",
                "category": "Vêtements",
                "image_url": "/placeholder.svg?height=200&width=200",
                "stock_quantity": 12,
                "is_active": True,
                "created_at": datetime.utcnow().isoformat()
            }
        ]
        return demo_products
    
    if MONGODB_AVAILABLE:
        user_id = current_user.get("_id") or current_user.get("id")
        products = list(products_collection.find({"user_id": user_id}))
        return serialize_mongo_doc(products)
    else:
        # Mode mémoire
        user_id = current_user.get("id")
        user_products = [p for p in memory_products if p.get("user_id") == user_id]
        return user_products

@app.post("/products")
async def create_product(product: ProductCreate, current_user: dict = Depends(get_current_user)):
    print(f"➕ Création d'un produit: {product.name}")
    
    user_id = current_user.get("_id") or current_user.get("id")
    
    if MONGODB_AVAILABLE:
        product_doc = {
            **product.model_dump(),  # Utiliser model_dump() au lieu de dict()
            "user_id": user_id,
            "is_active": True,
            "created_at": datetime.utcnow()
        }
        
        result = products_collection.insert_one(product_doc)
        product_doc["_id"] = result.inserted_id
        
        return serialize_mongo_doc(product_doc)
    else:
        # Mode mémoire
        product_id = str(uuid.uuid4())
        product_doc = {
            "id": product_id,
            **product.model_dump(),
            "user_id": user_id,
            "is_active": True,
            "created_at": datetime.utcnow().isoformat()
        }
        
        memory_products.append(product_doc)
        return product_doc

@app.put("/products/{product_id}")
async def update_product(product_id: str, product: ProductUpdate, current_user: dict = Depends(get_current_user)):
    print(f"✏️ Modification du produit: {product_id}")
    
    user_id = current_user.get("_id") or current_user.get("id")
    
    if MONGODB_AVAILABLE:
        update_data = {k: v for k, v in product.model_dump().items() if v is not None}
        update_data["updated_at"] = datetime.utcnow()
        
        result = products_collection.update_one(
            {"_id": ObjectId(product_id), "user_id": user_id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Produit non trouvé")
        
        updated_product = products_collection.find_one({"_id": ObjectId(product_id)})
        return serialize_mongo_doc(updated_product)
    else:
        # Mode mémoire
        for i, p in enumerate(memory_products):
            if p["id"] == product_id and p["user_id"] == user_id:
                update_data = {k: v for k, v in product.model_dump().items() if v is not None}
                memory_products[i].update(update_data)
                memory_products[i]["updated_at"] = datetime.utcnow().isoformat()
                return memory_products[i]
        
        raise HTTPException(status_code=404, detail="Produit non trouvé")

@app.delete("/products/{product_id}")
async def delete_product(product_id: str, current_user: dict = Depends(get_current_user)):
    print(f"🗑️ Suppression du produit: {product_id}")
    
    user_id = current_user.get("_id") or current_user.get("id")
    
    if MONGODB_AVAILABLE:
        result = products_collection.delete_one(
            {"_id": ObjectId(product_id), "user_id": user_id}
        )
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Produit non trouvé")
    else:
        # Mode mémoire
        for i, p in enumerate(memory_products):
            if p["id"] == product_id and p["user_id"] == user_id:
                memory_products.pop(i)
                break
        else:
            raise HTTPException(status_code=404, detail="Produit non trouvé")
    
    return {"message": "Produit supprimé avec succès"}

# Routes des commandes
@app.get("/orders")
async def get_orders(current_user: dict = Depends(get_current_user)):
    print(f"📋 Récupération des commandes pour: {current_user['email']}")
    
    # Commandes de démonstration
    if current_user.get("_id") == "demo" or current_user.get("id") == "demo":
        demo_orders = [
            {
                "id": "1",
                "order_id": "TJR20250530001",
                "client_name": "Ahmed Benali",
                "client_phone": "+212600123456",
                "client_address": "123 Rue Mohammed V",
                "city": "Casablanca",
                "status": "en_attente",
                "total_amount": 150.0,
                "delivery_fee": 25.0,
                "notes": "Livraison rapide demandée",
                "created_at": datetime.utcnow().isoformat()
            },
            {
                "id": "2",
                "order_id": "TJR20250530002",
                "client_name": "Fatima Zahra",
                "client_phone": "+212661234567",
                "client_address": "456 Avenue Hassan II",
                "city": "Rabat",
                "status": "en_livraison",
                "total_amount": 300.0,
                "delivery_fee": 30.0,
                "notes": "Commande urgente",
                "created_at": (datetime.utcnow() - timedelta(days=1)).isoformat()
            },
            {
                "id": "3",
                "order_id": "TJR20250529003",
                "client_name": "Omar Alami",
                "client_phone": "+212662345678",
                "client_address": "789 Boulevard Zerktouni",
                "city": "Marrakech",
                "status": "livree",
                "total_amount": 220.0,
                "delivery_fee": 35.0,
                "notes": "Client satisfait",
                "created_at": (datetime.utcnow() - timedelta(days=2)).isoformat()
            }
        ]
        return demo_orders
    
    if MONGODB_AVAILABLE:
        user_id = current_user.get("_id") or current_user.get("id")
        orders = list(orders_collection.find({"user_id": user_id}))
        return serialize_mongo_doc(orders)
    else:
        # Mode mémoire
        user_id = current_user.get("id")
        user_orders = [o for o in memory_orders if o.get("user_id") == user_id]
        return user_orders

@app.post("/orders")
async def create_order(order: OrderCreate, current_user: dict = Depends(get_current_user)):
    print(f"📦 Nouvelle commande: {order.client_name}")
    
    user_id = current_user.get("_id") or current_user.get("id")
    order_id = f"TJR{datetime.now().strftime('%Y%m%d')}{str(uuid.uuid4())[:6].upper()}"
    
    if MONGODB_AVAILABLE:
        order_doc = {
            **order.model_dump(),
            "order_id": order_id,
            "user_id": user_id,
            "status": "en_attente",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
        
        result = orders_collection.insert_one(order_doc)
        order_doc["_id"] = result.inserted_id
        
        return serialize_mongo_doc(order_doc)
    else:
        # Mode mémoire
        order_doc = {
            "id": str(uuid.uuid4()),
            **order.model_dump(),
            "order_id": order_id,
            "user_id": user_id,
            "status": "en_attente",
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat()
        }
        
        memory_orders.append(order_doc)
        return order_doc

# Routes des messages
@app.get("/messages")
async def get_messages(current_user: dict = Depends(get_current_user)):
    print(f"💬 Récupération des messages pour: {current_user['email']}")
    
    # Messages de démonstration
    if current_user.get("_id") == "demo" or current_user.get("id") == "demo":
        demo_messages = [
            {
                "id": "1",
                "phone": "+212600123456",
                "message": "Bonjour, avez-vous des t-shirts en stock ?",
                "ai_response": "Bonjour ! Oui, nous avons des t-shirts TJRIA Premium en stock. Quelle taille vous intéresse ?",
                "intent": "produit",
                "timestamp": datetime.utcnow().isoformat()
            },
            {
                "id": "2",
                "phone": "+212661234567",
                "message": "Je voudrais suivre ma commande TJR20250530002",
                "ai_response": "Votre commande TJR20250530002 est actuellement en livraison. Vous devriez la recevoir demain.",
                "intent": "suivi",
                "timestamp": (datetime.utcnow() - timedelta(hours=2)).isoformat()
            }
        ]
        return demo_messages
    
    if MONGODB_AVAILABLE:
        user_id = current_user.get("_id") or current_user.get("id")
        messages = list(messages_collection.find({"user_id": user_id}))
        return serialize_mongo_doc(messages)
    else:
        # Mode mémoire
        user_id = current_user.get("id")
        user_messages = [m for m in memory_messages if m.get("user_id") == user_id]
        return user_messages

# Routes WhatsApp
@app.get("/whatsapp/status")
async def whatsapp_status(current_user: dict = Depends(get_current_user)):
    return {"status": "disconnected", "message": "Cliquez sur 'Connecter' pour scanner le QR code"}

@app.post("/whatsapp/connect")
async def connect_whatsapp(current_user: dict = Depends(get_current_user)):
    # QR code de démonstration
    qr_code = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjBmMGYwIi8+CiAgPHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzMzMyIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkRlbW8gUVIgQ29kZTwvdGV4dD4KICA8dGV4dCB4PSI1MCUiIHk9IjcwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjEwIiBmaWxsPSIjNjY2IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSI+U2NhbiBhdmVjIFdoYXRzQXBwPC90ZXh0Pgo8L3N2Zz4K"
    return {"qr_code": qr_code, "message": "Scannez ce QR code avec WhatsApp"}

# Routes statistiques
@app.get("/stats/dashboard")
async def get_dashboard_stats(current_user: dict = Depends(get_current_user)):
    print(f"📊 Statistiques pour: {current_user['email']}")
    
    # Statistiques de démonstration
    if current_user.get("_id") == "demo" or current_user.get("id") == "demo":
        return {
            "total_orders": 3,
            "pending_orders": 1,
            "total_messages": 2,
            "total_products": 3,
            "total_revenue": 670.0,
            "orders_today": 1,
            "messages_today": 2
        }
    
    if MONGODB_AVAILABLE:
        user_id = current_user.get("_id") or current_user.get("id")
        total_orders = orders_collection.count_documents({"user_id": user_id})
        pending_orders = orders_collection.count_documents({"user_id": user_id, "status": "en_attente"})
        total_messages = messages_collection.count_documents({"user_id": user_id})
        total_products = products_collection.count_documents({"user_id": user_id})
        
        return {
            "total_orders": total_orders,
            "pending_orders": pending_orders,
            "total_messages": total_messages,
            "total_products": total_products
        }
    else:
        # Mode mémoire
        user_id = current_user.get("id")
        user_orders = [o for o in memory_orders if o.get("user_id") == user_id]
        user_messages = [m for m in memory_messages if m.get("user_id") == user_id]
        user_products = [p for p in memory_products if p.get("user_id") == user_id]
        
        return {
            "total_orders": len(user_orders),
            "pending_orders": len([o for o in user_orders if o.get("status") == "en_attente"]),
            "total_messages": len(user_messages),
            "total_products": len(user_products)
        }

# Routes IA
@app.get("/ai/analytics")
async def get_ai_analytics(current_user: dict = Depends(get_current_user)):
    print(f"🤖 Analytics IA pour: {current_user['email']}")
    
    return {
        "total_messages": 2,
        "ai_responses": 2,
        "intents_detected": {
            "produit": 1,
            "commande": 0,
            "suivi": 1,
            "general": 0
        },
        "response_time_avg": 850,
        "accuracy_rate": 95.5
    }

@app.post("/ai/test-message")
async def test_ai_message(data: dict, current_user: dict = Depends(get_current_user)):
    message = data.get("message", "")
    print(f"🤖 Test IA: {message}")
    
    if "produit" in message.lower() or "stock" in message.lower():
        response = "Bonjour ! Nous avons plusieurs produits en stock chez TJRIA. Que recherchez-vous exactement ?"
        intent = "produit"
    elif "commande" in message.lower():
        response = "Parfait ! Je peux vous aider à passer une commande chez TJRIA. Quel produit vous intéresse ?"
        intent = "commande"
    elif "prix" in message.lower():
        response = "Nos prix chez TJRIA sont très compétitifs. Pouvez-vous me dire quel article vous intéresse ?"
        intent = "produit"
    elif "suivi" in message.lower() or "livraison" in message.lower():
        response = "Je peux vous aider avec le suivi de votre commande. Pouvez-vous me donner votre numéro de commande ?"
        intent = "suivi"
    else:
        response = f"Merci de contacter TJRIA ! Comment puis-je vous aider aujourd'hui ?"
        intent = "general"
    
    return {
        "ai_response": response,
        "intent": intent,
        "confidence": 0.95,
        "response_time": 850
    }

@app.get("/")
async def root():
    db_status = "MongoDB" if MONGODB_AVAILABLE else "Mémoire (MongoDB non disponible)"
    return {
        "message": "✅ TJRIA - Agent WhatsApp IA Professionnel",
        "status": "running",
        "version": "2.0.0 Hybride",
        "database": db_status,
        "mongodb_available": MONGODB_AVAILABLE,
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    print("🚀 Démarrage de TJRIA - Agent WhatsApp IA Professionnel")
    print("📱 API disponible sur: http://localhost:8000")
    print("📚 Documentation: http://localhost:8000/docs")
    print("🔐 Identifiants de démonstration:")
    print("   📧 Email: admin@tjria.com")
    print("   🔒 Password: 123456")
    
    if MONGODB_AVAILABLE:
        print("🗄️ Base de données: MongoDB (connecté)")
        print("📦 Collection: whatsapp_agent_db")
    else:
        print("🗄️ Base de données: Mode mémoire (MongoDB non disponible)")
        print("⚠️ Les données seront perdues au redémarrage")
    
    print("✨ Design professionnel activé")
    print("✅ TJRIA prêt en mode hybride !")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
