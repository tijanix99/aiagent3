from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy import create_engine, Column, Integer, String, Text, DateTime, Boolean, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from jose import jwt, JWTError
import bcrypt
import uvicorn
import os
from typing import Optional, List
import uuid

# Configuration de la base de données
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://neondb_owner:npg_Z8aBuGmQJhzr@ep-rough-cherry-a5ixwrqz.us-east-2.aws.neon.tech/neondb?sslmode=require")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Configuration FastAPI
app = FastAPI(title="TJRIA - Agent WhatsApp IA", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Sécurité
security = HTTPBearer()
SECRET_KEY = "tjria-secret-key-2025"
ALGORITHM = "HS256"

# Modèles de base de données
class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    phone = Column(String(20), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    shop_name = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    products = relationship("Product", back_populates="owner")
    orders = relationship("Order", back_populates="owner")
    messages = relationship("Message", back_populates="owner")

class Product(Base):
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    price = Column(Float, nullable=False)
    size = Column(String(50))
    category = Column(String(100))
    image_url = Column(String(500))
    is_active = Column(Boolean, default=True)
    stock_quantity = Column(Integer, default=0)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    owner = relationship("User", back_populates="products")

class Order(Base):
    __tablename__ = "orders"
    
    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(String(50), unique=True, nullable=False)
    client_name = Column(String(255), nullable=False)
    client_phone = Column(String(20), nullable=False)
    client_address = Column(Text)
    city = Column(String(100))
    status = Column(String(50), default="en_attente")
    total_amount = Column(Float, nullable=False)
    delivery_fee = Column(Float, default=0)
    notes = Column(Text)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    owner = relationship("User", back_populates="orders")

class Message(Base):
    __tablename__ = "messages"
    
    id = Column(Integer, primary_key=True, index=True)
    phone = Column(String(20), nullable=False)
    message = Column(Text, nullable=False)
    ai_response = Column(Text)
    message_type = Column(String(50), default="text")
    intent = Column(String(100))
    is_spam = Column(Boolean, default=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    owner = relationship("User", back_populates="messages")

# Créer les tables
Base.metadata.create_all(bind=engine)

# Schémas Pydantic
class UserCreate(BaseModel):
    email: EmailStr
    name: str
    phone: str
    password: str
    shop_name: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class ProductCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    size: Optional[str] = None
    category: Optional[str] = None
    image_url: Optional[str] = None
    stock_quantity: Optional[int] = 0

class OrderCreate(BaseModel):
    client_name: str
    client_phone: str
    client_address: Optional[str] = None
    city: Optional[str] = None
    total_amount: float
    delivery_fee: Optional[float] = 0
    notes: Optional[str] = None

# Fonctions utilitaires
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=30)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Token invalide")
        return int(user_id)
    except JWTError:
        raise HTTPException(status_code=401, detail="Token invalide")

def get_current_user(user_id: int = Depends(verify_token), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="Utilisateur non trouvé")
    return user

# Routes d'authentification
@app.post("/auth/register")
async def register(user: UserCreate, db: Session = Depends(get_db)):
    existing_user = db.query(User).filter(User.email == user.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email déjà utilisé")
    
    hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    
    db_user = User(
        email=user.email,
        name=user.name,
        phone=user.phone,
        hashed_password=hashed_password.decode('utf-8'),
        shop_name=user.shop_name
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return {"message": "Utilisateur créé avec succès", "user_id": db_user.id}

@app.post("/auth/login")
async def login(credentials: UserLogin, db: Session = Depends(get_db)):
    print(f"🔐 Tentative de connexion TJRIA: {credentials.email}")
    
    user = db.query(User).filter(User.email == credentials.email).first()
    if not user or not bcrypt.checkpw(credentials.password.encode('utf-8'), user.hashed_password.encode('utf-8')):
        # Utilisateur de test pour la démo
        if credentials.email == "admin@tjria.com" and credentials.password == "123456":
            access_token = create_access_token(data={"sub": "1"})
            return {
                "access_token": access_token,
                "token_type": "bearer",
                "user": {
                    "id": "1",
                    "email": "admin@tjria.com",
                    "name": "Admin TJRIA",
                    "shop_name": "TJRIA Store"
                }
            }
        raise HTTPException(status_code=401, detail="Email ou mot de passe incorrect")
    
    access_token = create_access_token(data={"sub": str(user.id)})
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "shop_name": user.shop_name
        }
    }

# Routes des produits
@app.get("/products")
async def get_products(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    products = db.query(Product).filter(Product.user_id == current_user.id).all()
    return products

@app.post("/products")
async def create_product(product: ProductCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db_product = Product(**product.dict(), user_id=current_user.id)
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product

@app.put("/products/{product_id}")
async def update_product(product_id: int, product: ProductCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db_product = db.query(Product).filter(Product.id == product_id, Product.user_id == current_user.id).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Produit non trouvé")
    
    for key, value in product.dict().items():
        setattr(db_product, key, value)
    
    db.commit()
    db.refresh(db_product)
    return db_product

@app.delete("/products/{product_id}")
async def delete_product(product_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db_product = db.query(Product).filter(Product.id == product_id, Product.user_id == current_user.id).first()
    if not db_product:
        raise HTTPException(status_code=404, detail="Produit non trouvé")
    
    db.delete(db_product)
    db.commit()
    return {"message": "Produit supprimé"}

# Routes des commandes
@app.get("/orders")
async def get_orders(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    orders = db.query(Order).filter(Order.user_id == current_user.id).all()
    return orders

@app.post("/orders")
async def create_order(order: OrderCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    order_id = f"TJR{datetime.now().strftime('%Y%m%d')}{str(uuid.uuid4())[:6].upper()}"
    
    db_order = Order(
        **order.dict(),
        order_id=order_id,
        user_id=current_user.id
    )
    
    db.add(db_order)
    db.commit()
    db.refresh(db_order)
    return db_order

# Routes des messages
@app.get("/messages")
async def get_messages(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    messages = db.query(Message).filter(Message.user_id == current_user.id).all()
    return messages

# Routes WhatsApp
@app.get("/whatsapp/status")
async def whatsapp_status(current_user: User = Depends(get_current_user)):
    return {"status": "disconnected"}

@app.post("/whatsapp/connect")
async def connect_whatsapp(current_user: User = Depends(get_current_user)):
    qr_code = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
    return {"qr_code": qr_code}

# Routes statistiques
@app.get("/stats/dashboard")
async def get_dashboard_stats(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    total_orders = db.query(Order).filter(Order.user_id == current_user.id).count()
    pending_orders = db.query(Order).filter(Order.user_id == current_user.id, Order.status == "en_attente").count()
    total_messages = db.query(Message).filter(Message.user_id == current_user.id).count()
    total_products = db.query(Product).filter(Product.user_id == current_user.id).count()
    
    return {
        "total_orders": total_orders,
        "pending_orders": pending_orders,
        "total_messages": total_messages,
        "total_products": total_products
    }

# Routes IA
@app.get("/ai/analytics")
async def get_ai_analytics(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user_messages = db.query(Message).filter(Message.user_id == current_user.id).all()
    
    return {
        "total_messages": len(user_messages),
        "ai_responses": len([m for m in user_messages if m.ai_response]),
        "intents_detected": {
            "produit": len([m for m in user_messages if m.intent == "produit"]),
            "commande": len([m for m in user_messages if m.intent == "commande"]),
            "suivi": len([m for m in user_messages if m.intent == "suivi"]),
            "general": len([m for m in user_messages if m.intent == "general"])
        },
        "response_time_avg": 1200
    }

@app.post("/ai/test-message")
async def test_ai_message(data: dict, current_user: User = Depends(get_current_user)):
    message = data.get("message", "")
    
    if "produit" in message.lower() or "stock" in message.lower():
        response = "Bonjour ! Nous avons plusieurs produits en stock chez TJRIA. Que recherchez-vous exactement ?"
    elif "commande" in message.lower():
        response = "Parfait ! Je peux vous aider à passer une commande chez TJRIA. Quel produit vous intéresse ?"
    elif "prix" in message.lower():
        response = "Nos prix chez TJRIA sont très compétitifs. Pouvez-vous me dire quel article vous intéresse ?"
    else:
        response = f"Merci de contacter TJRIA ! Votre message : '{message}'. Comment puis-je vous aider aujourd'hui ?"
    
    return {"ai_response": response}

@app.get("/")
async def root():
    return {
        "message": "✅ TJRIA - Agent WhatsApp IA Professionnel",
        "status": "running",
        "version": "2.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    print("🚀 Démarrage de TJRIA - Agent WhatsApp IA Professionnel")
    print("📱 API disponible sur: http://localhost:8000")
    print("📚 Documentation: http://localhost:8000/docs")
    print("🔐 Identifiants de démonstration:")
    print("   📧 Email: admin@tjria.com")
    print("   🔒 Password: 123456")
    print("🗄️ Base de données: PostgreSQL (Neon)")
    print("✨ Design professionnel activé")
    print("✅ TJRIA prêt !")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
