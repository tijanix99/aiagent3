"use client"
import { Dashboard } from "@/components/dashboard"
import { LoginForm } from "@/components/auth/login-form"
import { useAuth } from "@/hooks/use-auth"
import { useEffect, useState } from "react"

export default function Home() {
  const { user, loading, connectionStatus } = useAuth()
  const [forceShow, setForceShow] = useState(false)

  // Force l'affichage après 5 secondes si toujours en chargement
  useEffect(() => {
    const timer = setTimeout(() => {
      if (loading) {
        console.log("⏰ Timeout atteint, affichage forcé de l'interface")
        setForceShow(true)
      }
    }, 5000) // 5 secondes maximum

    return () => clearTimeout(timer)
  }, [loading])

  // Si l'utilisateur est connecté, afficher le dashboard
  if (user) {
    return <Dashboard />
  }

  // Si on force l'affichage OU si le chargement est terminé, afficher le login
  if (forceShow || !loading) {
    return <LoginForm />
  }

  // Écran de chargement avec bouton de secours
  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="text-center">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
        <div className="text-2xl font-bold text-blue-900 mb-2">TJRIA</div>
        <div className="text-gray-600 mb-4">Agent WhatsApp IA</div>
        <div className="text-sm text-gray-500 mb-6">
          {connectionStatus === "checking" ? "Vérification du serveur..." : "Chargement..."}
        </div>

        {/* Boutons de secours */}
        <div className="space-y-3">
          <button
            onClick={() => setForceShow(true)}
            className="block mx-auto px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Continuer sans attendre
          </button>

          <button
            onClick={() => window.location.reload()}
            className="block mx-auto px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors text-sm"
          >
            Actualiser la page
          </button>
        </div>

        <div className="mt-6 text-xs text-gray-400">Si le chargement persiste, vérifiez que le backend est démarré</div>
      </div>
    </div>
  )
}
