"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Search, Bot, Send, MoreHorizontal, QrCode, Smartphone, Wifi, WifiOff } from "lucide-react"

interface Contact {
  id: string
  name: string
  lastMessage: string
  time: string
  avatar: string
  unread?: number
}

interface Message {
  id: string
  sender: string
  content: string
  time: string
  isBot?: boolean
}

interface WhatsAppSectionProps {
  onStatusChange: (status: string) => void
}

export function WhatsAppSection({ onStatusChange }: WhatsAppSectionProps) {
  const [selectedContact, setSelectedContact] = useState<string>("1")
  const [newMessage, setNewMessage] = useState("")
  const [whatsappStatus, setWhatsappStatus] = useState("disconnected")
  const [qrCode, setQrCode] = useState("")
  const [loading, setLoading] = useState(false)
  const [contacts, setContacts] = useState<Contact[]>([])
  const [messages, setMessages] = useState<Message[]>([])

  useEffect(() => {
    checkWhatsAppStatus()
    loadContacts()
    loadMessages()
  }, [])

  const checkWhatsAppStatus = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/whatsapp/status", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      const data = await response.json()
      setWhatsappStatus(data.status)
      onStatusChange(data.status)

      if (data.qr_code) {
        setQrCode(data.qr_code)
      }
    } catch (error) {
      console.error("Erreur vérification WhatsApp:", error)
    }
  }

  const connectWhatsApp = async () => {
    setLoading(true)
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/whatsapp/connect", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      const data = await response.json()

      if (data.qr_code) {
        setQrCode(data.qr_code)
        setWhatsappStatus("waiting_qr")
        onStatusChange("waiting_qr")
      }
    } catch (error) {
      console.error("Erreur connexion WhatsApp:", error)
    }
    setLoading(false)
  }

  const disconnectWhatsApp = async () => {
    try {
      const token = localStorage.getItem("token")
      await fetch("http://localhost:8000/whatsapp/disconnect", {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      setWhatsappStatus("disconnected")
      setQrCode("")
      onStatusChange("disconnected")
    } catch (error) {
      console.error("Erreur déconnexion WhatsApp:", error)
    }
  }

  const loadContacts = async () => {
    // Charger les contacts depuis l'API
    // Pour l'instant, utiliser des données de test
    setContacts([
      {
        id: "1",
        name: "Client Test",
        lastMessage: "Bonjour, avez-vous ce produit en stock ?",
        time: "10:30",
        avatar: "/placeholder.svg?height=40&width=40",
        unread: 2,
      },
    ])
  }

  const loadMessages = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/messages", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      const data = await response.json()
      setMessages(
        data.map((msg: any) => ({
          id: msg.id,
          sender: msg.phone,
          content: msg.message,
          time: new Date(msg.timestamp).toLocaleTimeString(),
          isBot: false,
        })),
      )
    } catch (error) {
      console.error("Erreur chargement messages:", error)
    }
  }

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedContact) return

    try {
      const token = localStorage.getItem("token")
      const contact = contacts.find((c) => c.id === selectedContact)

      await fetch("http://localhost:8000/messages/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          phone: contact?.name || "test",
          message: newMessage,
        }),
      })

      // Ajouter le message à la liste locale
      const newMsg: Message = {
        id: Date.now().toString(),
        sender: "Vous",
        content: newMessage,
        time: new Date().toLocaleTimeString(),
        isBot: false,
      }
      setMessages((prev) => [...prev, newMsg])
      setNewMessage("")
    } catch (error) {
      console.error("Erreur envoi message:", error)
    }
  }

  const renderConnectionStatus = () => {
    if (whatsappStatus === "disconnected") {
      return (
        <Card className="mb-6">
          <CardContent className="p-6 text-center">
            <WifiOff className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">WhatsApp non connecté</h3>
            <p className="text-gray-600 mb-4">
              Connectez votre WhatsApp pour commencer à recevoir des messages automatiquement
            </p>
            <Button onClick={connectWhatsApp} disabled={loading} className="bg-green-600 hover:bg-green-700">
              <QrCode className="h-4 w-4 mr-2" />
              {loading ? "Connexion..." : "Connecter WhatsApp"}
            </Button>
          </CardContent>
        </Card>
      )
    }

    if (whatsappStatus === "waiting_qr" && qrCode) {
      return (
        <Card className="mb-6">
          <CardContent className="p-6 text-center">
            <Smartphone className="h-12 w-12 text-blue-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Scanner le QR Code</h3>
            <p className="text-gray-600 mb-4">Ouvrez WhatsApp sur votre téléphone et scannez ce QR code</p>
            <div className="bg-white p-4 rounded-lg inline-block border">
              <img src={qrCode || "/placeholder.svg"} alt="QR Code WhatsApp" className="w-48 h-48" />
            </div>
            <div className="mt-4">
              <Button variant="outline" onClick={disconnectWhatsApp}>
                Annuler
              </Button>
            </div>
          </CardContent>
        </Card>
      )
    }

    if (whatsappStatus === "connected") {
      return (
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Wifi className="h-6 w-6 text-green-500" />
                <div>
                  <p className="font-medium text-green-700">WhatsApp connecté</p>
                  <p className="text-sm text-gray-600">Réception automatique des messages active</p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={disconnectWhatsApp}>
                Déconnecter
              </Button>
            </div>
          </CardContent>
        </Card>
      )
    }
  }

  return (
    <div className="space-y-6">
      {/* Statut de connexion */}
      {renderConnectionStatus()}

      {/* Interface de chat (seulement si connecté) */}
      {whatsappStatus === "connected" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Messages WhatsApp */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">Messages WhatsApp</CardTitle>
                <div className="flex items-center space-x-2">
                  <Search className="h-4 w-4 text-gray-400" />
                  <Input placeholder="Rechercher..." className="w-32" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 h-96">
                {/* Liste des contacts */}
                <div className="border-r pr-4">
                  <h3 className="font-semibold mb-4">Conversations</h3>
                  <ScrollArea className="h-80">
                    <div className="space-y-3">
                      {contacts.map((contact) => (
                        <div
                          key={contact.id}
                          className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-colors ${
                            selectedContact === contact.id ? "bg-blue-50" : "hover:bg-gray-50"
                          }`}
                          onClick={() => setSelectedContact(contact.id)}
                        >
                          <Avatar>
                            <AvatarImage src={contact.avatar || "/placeholder.svg"} />
                            <AvatarFallback>{contact.name.slice(0, 2)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-sm truncate">{contact.name}</p>
                              <span className="text-xs text-gray-500">{contact.time}</span>
                            </div>
                            <p className="text-sm text-gray-600 truncate">{contact.lastMessage}</p>
                          </div>
                          {contact.unread && <Badge className="bg-blue-600 text-white">{contact.unread}</Badge>}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>

                {/* Zone de chat */}
                <div className="flex flex-col">
                  <div className="flex items-center justify-between p-3 border-b">
                    <div className="flex items-center space-x-3">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=32&width=32" />
                        <AvatarFallback>CT</AvatarFallback>
                      </Avatar>
                      <span className="font-medium">Client Test</span>
                    </div>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>

                  <ScrollArea className="flex-1 p-4">
                    <div className="space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.sender === "Vous" ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-xs px-4 py-2 rounded-lg ${
                              message.sender === "Vous" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-900"
                            }`}
                          >
                            {message.isBot && (
                              <div className="flex items-center space-x-1 mb-1">
                                <Bot className="h-3 w-3" />
                                <span className="text-xs font-medium">IA</span>
                              </div>
                            )}
                            <p className="text-sm">{message.content}</p>
                            <p className="text-xs opacity-70 mt-1">{message.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>

                  <div className="p-3 border-t">
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Tapez votre message..."
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                        className="flex-1"
                      />
                      <Button size="sm" onClick={sendMessage}>
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Statistiques et IA */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Bot className="h-5 w-5 text-blue-600" />
                  <span>Assistant IA</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">Réponses automatiques</h4>
                  <p className="text-sm text-blue-700">L'IA répond automatiquement aux questions clients</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-900 mb-2">Détection d'intentions</h4>
                  <p className="text-sm text-green-700">Analyse intelligente des demandes clients</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Statistiques</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Messages reçus</span>
                  <span className="font-medium">24</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Réponses IA</span>
                  <span className="font-medium">18</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Taux de réponse</span>
                  <span className="font-medium">75%</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  )
}
