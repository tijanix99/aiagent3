"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Bot, Brain, MessageSquare, TrendingUp, Settings } from "lucide-react"

interface AIAnalytics {
  total_messages: number
  ai_responses: number
  intents_detected: {
    produit: number
    commande: number
    suivi: number
    general: number
  }
  response_time_avg: number
}

export function AISection() {
  const [analytics, setAnalytics] = useState<AIAnalytics | null>(null)
  const [testMessage, setTestMessage] = useState("")
  const [testResponse, setTestResponse] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadAnalytics()
  }, [])

  const loadAnalytics = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/ai/analytics", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      const data = await response.json()
      setAnalytics(data)
    } catch (error) {
      console.error("Erreur chargement analytics IA:", error)
    }
  }

  const testAI = async () => {
    if (!testMessage.trim()) return

    setLoading(true)
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/ai/test-message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: testMessage,
        }),
      })
      const data = await response.json()
      setTestResponse(data.ai_response)
    } catch (error) {
      console.error("Erreur test IA:", error)
      setTestResponse("Erreur lors du test de l'IA")
    }
    setLoading(false)
  }

  return (
    <div className="space-y-6">
      {/* En-tête */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Intelligence Artificielle</h2>
          <p className="text-gray-600">Gestion et analyse de votre assistant IA</p>
        </div>
        <Button variant="outline">
          <Settings className="h-4 w-4 mr-2" />
          Configurer IA
        </Button>
      </div>

      {/* Statistiques IA */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold">{analytics?.total_messages || 0}</p>
                <p className="text-sm text-gray-600">Messages traités</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Bot className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{analytics?.ai_responses || 0}</p>
                <p className="text-sm text-gray-600">Réponses IA</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Brain className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold">
                  {analytics ? Math.round((analytics.ai_responses / analytics.total_messages) * 100) || 0 : 0}%
                </p>
                <p className="text-sm text-gray-600">Taux de réponse</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-2xl font-bold">{analytics?.response_time_avg || 0}ms</p>
                <p className="text-sm text-gray-600">Temps de réponse</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Test de l'IA */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bot className="h-5 w-5 text-blue-600" />
              <span>Tester l'IA</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium">Message test :</label>
              <Textarea
                placeholder="Tapez un message pour tester l'IA..."
                value={testMessage}
                onChange={(e) => setTestMessage(e.target.value)}
                rows={3}
              />
            </div>
            <Button onClick={testAI} disabled={loading} className="w-full">
              {loading ? "Test en cours..." : "Tester l'IA"}
            </Button>
            {testResponse && (
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium text-blue-900 mb-2">Réponse de l'IA :</p>
                <p className="text-blue-800">{testResponse}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Intentions détectées */}
        <Card>
          <CardHeader>
            <CardTitle>Intentions détectées</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analytics?.intents_detected &&
                Object.entries(analytics.intents_detected).map(([intent, count]) => (
                  <div key={intent} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="capitalize">
                        {intent}
                      </Badge>
                    </div>
                    <span className="font-medium">{count}</span>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Configuration IA */}
      <Card>
        <CardHeader>
          <CardTitle>Configuration de l'IA</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Modèle IA :</label>
              <Input value="GPT-4" disabled />
            </div>
            <div>
              <label className="text-sm font-medium">Température :</label>
              <Input value="0.7" type="number" step="0.1" min="0" max="1" />
            </div>
            <div>
              <label className="text-sm font-medium">Tokens max :</label>
              <Input value="300" type="number" />
            </div>
            <div>
              <label className="text-sm font-medium">Délai de réponse (ms) :</label>
              <Input value="2000" type="number" />
            </div>
          </div>
          <Button className="w-full">Sauvegarder la configuration</Button>
        </CardContent>
      </Card>
    </div>
  )
}
