"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/hooks/use-auth"
import { Bot, Mail, Lock, AlertCircle, CheckCircle, XCircle, Sparkles, RefreshCw } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [mounted, setMounted] = useState(false)
  const { login, connectionStatus } = useAuth()

  useEffect(() => {
    setMounted(true)
    setEmail("admin@tjria.com")
    setPassword("123456")
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    console.log("🚀 Soumission du formulaire avec:", { email, password })

    if (connectionStatus === "disconnected") {
      setError("Serveur non accessible. Vérifiez que le backend est démarré sur le port 8000.")
      setLoading(false)
      return
    }

    const success = await login(email, password)

    if (!success) {
      setError("Email ou mot de passe incorrect. Vérifiez la console pour plus de détails.")
    }

    setLoading(false)
  }

  const testBackend = async () => {
    try {
      setError("")
      const response = await fetch("http://localhost:8000/")
      if (response.ok) {
        const data = await response.json()
        alert(`✅ Backend accessible: ${data.message}`)
      } else {
        alert(`❌ Backend répond mais erreur: ${response.status}`)
      }
    } catch (error) {
      alert(`❌ Backend non accessible: ${error.message}`)
      setError("Backend non accessible. Démarrez le serveur avec: python main_tjria_mongo.py")
    }
  }

  const getConnectionStatusIcon = () => {
    switch (connectionStatus) {
      case "connected":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "disconnected":
        return <XCircle className="h-4 w-4 text-red-500" />
      default:
        return <AlertCircle className="h-4 w-4 text-yellow-500 animate-pulse" />
    }
  }

  const getConnectionStatusText = () => {
    switch (connectionStatus) {
      case "connected":
        return "Serveur connecté"
      case "disconnected":
        return "Serveur déconnecté"
      default:
        return "Vérification..."
    }
  }

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>

      <Card className="w-full max-w-md shadow-2xl border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center pb-8">
          <div className="mx-auto mb-6 relative">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-purple-600 shadow-lg">
              <Bot className="h-8 w-8 text-white" />
            </div>
            <div className="absolute -top-1 -right-1">
              <Sparkles className="h-6 w-6 text-yellow-500 animate-pulse" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            TJRIA
          </CardTitle>
          <CardDescription className="text-lg text-gray-600 mt-2">Agent WhatsApp IA Professionnel</CardDescription>

          {/* Statut de connexion */}
          <div className="flex items-center justify-center space-x-2 mt-4 p-2 rounded-lg bg-gray-50">
            {getConnectionStatusIcon()}
            <span className="text-sm font-medium text-gray-700">{getConnectionStatusText()}</span>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {connectionStatus === "disconnected" && (
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <strong>Serveur non accessible !</strong>
                <br />
                Démarrez le backend avec :
                <br />
                <code className="text-xs bg-red-100 px-1 rounded">python main_tjria_mongo.py</code>
              </AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-semibold text-gray-700">
                Adresse email
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@tjria.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-12 h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-semibold text-gray-700">
                Mot de passe
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-12 h-12 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            {error && (
              <Alert variant="destructive" className="border-red-200 bg-red-50">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-red-800">{error}</AlertDescription>
              </Alert>
            )}

            <Button
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold rounded-lg shadow-lg transition-all duration-200 transform hover:scale-[1.02]"
              disabled={loading || connectionStatus === "disconnected"}
            >
              {loading ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  <span>Connexion...</span>
                </div>
              ) : (
                "Se connecter"
              )}
            </Button>

            <Button type="button" variant="outline" className="w-full h-10" onClick={testBackend}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Tester la connexion serveur
            </Button>

            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <p className="text-sm font-medium text-gray-600 mb-2">Identifiants de démonstration :</p>
              <div className="space-y-1 text-sm text-gray-500">
                <p>
                  <strong>Email:</strong> admin@tjria.com
                </p>
                <p>
                  <strong>Mot de passe:</strong> 123456
                </p>
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
