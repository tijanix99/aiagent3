"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Package,
  ShoppingCart,
  MessageCircle,
  Bell,
  Settings,
  LogOut,
  Bot,
  BarChart3,
  TrendingUp,
  Sparkles,
} from "lucide-react"
import { ProductsSection } from "./products-section"
import { OrdersSection } from "./orders-section"
import { WhatsAppSection } from "./whatsapp-section"
import { Sidebar } from "./sidebar"
import { AISection } from "./ai-section"
import { useAuth } from "@/hooks/use-auth"
import { Badge } from "@/components/ui/badge"

export function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const { user, logout } = useAuth()
  const [whatsappStatus, setWhatsappStatus] = useState("disconnected")
  const [stats, setStats] = useState({
    total_orders: 0,
    pending_orders: 0,
    total_messages: 0,
    total_products: 0,
  })

  useEffect(() => {
    checkWhatsAppStatus()
    loadStats()
  }, [])

  const checkWhatsAppStatus = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/whatsapp/status", {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await response.json()
      setWhatsappStatus(data.status)
    } catch (error) {
      console.error("Erreur vérification WhatsApp:", error)
    }
  }

  const loadStats = async () => {
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("http://localhost:8000/stats/dashboard", {
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await response.json()
      setStats(data)
    } catch (error) {
      console.error("Erreur chargement stats:", error)
    }
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-purple-600">
                  <Sparkles className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    TJRIA
                  </h1>
                  <p className="text-sm text-gray-500">{user?.shop_name || "Dashboard"}</p>
                </div>
              </div>

              <div className="hidden md:flex items-center space-x-4 ml-8">
                <span className="text-sm text-gray-500">
                  {new Date().toLocaleDateString("fr-FR", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>

                {/* Indicateur WhatsApp */}
                <div className="flex items-center space-x-2">
                  <div
                    className={`w-2 h-2 rounded-full ${whatsappStatus === "connected" ? "bg-green-500" : "bg-red-500"}`}
                  />
                  <span className="text-xs text-gray-500">
                    WhatsApp {whatsappStatus === "connected" ? "Connecté" : "Déconnecté"}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" className="relative">
                <Bell className="h-4 w-4" />
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center bg-red-500 text-white text-xs">
                  3
                </Badge>
              </Button>

              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4" />
              </Button>

              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4" />
              </Button>

              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback className="bg-gradient-to-br from-blue-600 to-purple-600 text-white">
                  {user?.name?.charAt(0) || "T"}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-5 bg-white border border-gray-200 p-1 rounded-xl shadow-sm">
              <TabsTrigger
                value="overview"
                className="flex items-center space-x-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Aperçu</span>
              </TabsTrigger>
              <TabsTrigger
                value="products"
                className="flex items-center space-x-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <Package className="h-4 w-4" />
                <span className="hidden sm:inline">Produits</span>
              </TabsTrigger>
              <TabsTrigger
                value="orders"
                className="flex items-center space-x-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <ShoppingCart className="h-4 w-4" />
                <span className="hidden sm:inline">Commandes</span>
              </TabsTrigger>
              <TabsTrigger
                value="messages"
                className="flex items-center space-x-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <MessageCircle className="h-4 w-4" />
                <span className="hidden sm:inline">WhatsApp</span>
              </TabsTrigger>
              <TabsTrigger
                value="ai"
                className="flex items-center space-x-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white"
              >
                <Bot className="h-4 w-4" />
                <span className="hidden sm:inline">IA</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Commandes</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.total_orders}</p>
                    </div>
                    <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <ShoppingCart className="h-6 w-6 text-blue-600" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">En Attente</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.pending_orders}</p>
                    </div>
                    <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-yellow-600" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Messages</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.total_messages}</p>
                    </div>
                    <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <MessageCircle className="h-6 w-6 text-green-600" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Produits</p>
                      <p className="text-3xl font-bold text-gray-900">{stats.total_products}</p>
                    </div>
                    <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Package className="h-6 w-6 text-purple-600" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <h3 className="text-lg font-semibold mb-4">Activité Récente</h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">Nouvelle commande reçue</span>
                      <span className="text-xs text-gray-400 ml-auto">Il y a 5 min</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">Message WhatsApp traité par IA</span>
                      <span className="text-xs text-gray-400 ml-auto">Il y a 12 min</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="h-2 w-2 bg-purple-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">Nouveau produit ajouté</span>
                      <span className="text-xs text-gray-400 ml-auto">Il y a 1h</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
                  <h3 className="text-lg font-semibold mb-4">Performance IA</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Taux de réponse</span>
                      <span className="text-sm font-semibold text-green-600">94%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Temps de réponse moyen</span>
                      <span className="text-sm font-semibold text-blue-600">1.2s</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Satisfaction client</span>
                      <span className="text-sm font-semibold text-purple-600">4.8/5</span>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="products" className="space-y-6">
              <ProductsSection />
            </TabsContent>

            <TabsContent value="orders" className="space-y-6">
              <OrdersSection />
            </TabsContent>

            <TabsContent value="messages" className="space-y-6">
              <WhatsAppSection onStatusChange={setWhatsappStatus} />
            </TabsContent>

            <TabsContent value="ai" className="space-y-6">
              <AISection />
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  )
}
