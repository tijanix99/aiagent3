"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Order {
  id: string
  client: string
  clientInfo: string
  product: string
  productInfo: string
  status: "An atterris" | "En livraison" | "Livraison" | "En attentis" | "En retoulant"
  date: string
}

export function OrdersSection() {
  const [orders] = useState<Order[]>([
    {
      id: "1024",
      client: "Sepma Davard",
      clientInfo: "JETHH Éric 0:200",
      product: "12 BTC bons",
      productInfo: "Communitauma",
      status: "An atterris",
      date: "25/05",
    },
    {
      id: "1022",
      client: "Trech Robe",
      clientInfo: "JDHF BDH 1:200",
      product: "123 Rue A. AB C",
      productInfo: "Communitauma",
      status: "En livraison",
      date: "28/05",
    },
    {
      id: "1022",
      client: "Gerneau Pone",
      clientInfo: "JDHF BDH 1:551",
      product: "123 Rue D. Anaissom",
      productInfo: "Communa",
      status: "Livraison",
      date: "24/05",
    },
    {
      id: "1021",
      client: "Aros Lafelure",
      clientInfo: "JDHF BDH 1:500",
      product: "125 Rue A. Cha",
      productInfo: "Communa",
      status: "An atterris",
      date: "28/05",
    },
    {
      id: "1020",
      client: "Juice Bovel",
      clientInfo: "JDHF BDH 1:150",
      product: "200 C. Jore",
      productInfo: "Communitauma",
      status: "En retoulant",
      date: "28/05",
    },
    {
      id: "1018",
      client: "Puui Brudin",
      clientInfo: "JDHF BDH 1:0100",
      product: "110 CH. Rems",
      productInfo: "Communitauma",
      status: "En attentis",
      date: "18/05",
    },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "An atterris":
        return "bg-green-100 text-green-800"
      case "En livraison":
        return "bg-blue-100 text-blue-800"
      case "Livraison":
        return "bg-purple-100 text-purple-800"
      case "En attentis":
        return "bg-yellow-100 text-yellow-800"
      case "En retoulant":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">Commandes</CardTitle>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-500">28 mar 2025</span>
            <Select defaultValue="communal">
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="communal">Agita communal</SelectItem>
                <SelectItem value="regional">Agita régional</SelectItem>
                <SelectItem value="national">Agita national</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID du commande</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Produit commandé</TableHead>
                <TableHead>Statut es commen</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order, index) => (
                <TableRow key={index}>
                  <TableCell className="font-medium">{order.id}</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{order.client}</div>
                      <div className="text-sm text-gray-500">{order.clientInfo}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{order.product}</div>
                      <div className="text-sm text-gray-500">{order.productInfo}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                  </TableCell>
                  <TableCell>{order.date}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
