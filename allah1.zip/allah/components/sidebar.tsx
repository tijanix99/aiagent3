"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Package, BarChart3 } from "lucide-react"

export function Sidebar() {
  const stats = [
    {
      title: "Dentrade",
      value: "107",
      icon: TrendingUp,
      color: "text-orange-600",
    },
    {
      title: "D4HR",
      value: "2h1 fronts",
      subtitle: "un interceptus",
      icon: Package,
      color: "text-blue-600",
    },
  ]

  const popularProducts = [
    { rank: 1, name: "S print", sales: "1 t" },
    { rank: 2, name: "Roba", sales: "2 g" },
    { rank: 3, name: "Jeans", sales: "40 s" },
    { rank: 4, name: "Chaussures", sales: "1 r" },
  ]

  return (
    <div className="w-80 bg-white border-r border-gray-200 p-6 space-y-6">
      {/* Agent Info */}
      <div className="text-sm text-gray-600">Agent intelligent WhatsApp Agent</div>

      {/* Stats Cards */}
      <div className="space-y-4">
        {stats.map((stat, index) => (
          <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <stat.icon className={`h-5 w-5 ${stat.color}`} />
                    <span className="font-semibold text-lg">{stat.value}</span>
                  </div>
                  <p className="text-sm text-gray-600">{stat.title}</p>
                  {stat.subtitle && <p className="text-xs text-gray-500">{stat.subtitle}</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Ventes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            <span>Ventes</span>
          </CardTitle>
          <p className="text-sm text-gray-600">100 Waresagamebotspaces</p>
        </CardHeader>
      </Card>

      {/* Produits populaires */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center space-x-2">
            <Package className="h-5 w-5 text-red-600" />
            <span>Produits populaires</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {popularProducts.map((product) => (
            <div key={product.rank} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Badge variant="outline" className="w-6 h-6 rounded-full p-0 flex items-center justify-center">
                  {product.rank}
                </Badge>
                <span className="text-sm">{product.name}</span>
              </div>
              <span className="text-sm text-gray-500">{product.sales}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Commandes par jour */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm text-gray-600">Commandes par jour</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">120</div>
          <div className="h-20 mt-4">
            {/* Simple chart representation */}
            <div className="flex items-end space-x-1 h-full">
              {[40, 60, 45, 80, 65, 90, 75].map((height, index) => (
                <div key={index} className="bg-blue-500 rounded-t flex-1" style={{ height: `${height}%` }} />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
