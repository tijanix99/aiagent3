"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Plus, Search, Edit, Trash2, AlertCircle } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface Product {
  id: number | string
  name: string
  price: number
  description: string
  size: string
  category: string
  is_active: boolean
  stock_quantity: number
  image_url?: string
  created_at: string
}

export function ProductsSection() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    description: "",
    size: "",
    category: "",
    stock_quantity: "",
    image_url: "",
  })

  useEffect(() => {
    loadProducts()
  }, [])

  const loadProducts = async () => {
    try {
      setError(null)
      const token = localStorage.getItem("token")

      if (!token) {
        setError("Token manquant. Veuillez vous reconnecter.")
        setLoading(false)
        return
      }

      console.log("🔄 Chargement des produits...")

      const response = await fetch("http://localhost:8000/products", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      })

      console.log("📡 Statut de la réponse:", response.status)

      if (response.ok) {
        const data = await response.json()
        console.log("✅ Produits chargés:", data)
        setProducts(data)
      } else if (response.status === 401) {
        setError("Session expirée. Veuillez vous reconnecter.")
        // Ne pas déconnecter automatiquement, laisser l'utilisateur décider
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Erreur inconnue" }))
        setError(`Erreur ${response.status}: ${errorData.detail || "Impossible de charger les produits"}`)
      }
    } catch (error) {
      console.error("❌ Erreur chargement produits:", error)
      setError("Erreur de connexion. Vérifiez que le serveur est démarré.")
    }
    setLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitting(true)
    setError(null)

    try {
      const token = localStorage.getItem("token")

      if (!token) {
        setError("Token manquant. Veuillez vous reconnecter.")
        setSubmitting(false)
        return
      }

      // Validation des données
      if (!formData.name.trim()) {
        setError("Le nom du produit est obligatoire")
        setSubmitting(false)
        return
      }

      if (!formData.price || Number.parseFloat(formData.price) <= 0) {
        setError("Le prix doit être supérieur à 0")
        setSubmitting(false)
        return
      }

      const productData = {
        name: formData.name.trim(),
        price: Number.parseFloat(formData.price),
        description: formData.description.trim() || null,
        size: formData.size.trim() || null,
        category: formData.category.trim() || null,
        stock_quantity: Number.parseInt(formData.stock_quantity) || 0,
        image_url: formData.image_url.trim() || null,
      }

      console.log("📦 Données du produit à envoyer:", productData)

      const url = editingProduct
        ? `http://localhost:8000/products/${editingProduct.id}`
        : "http://localhost:8000/products"

      const method = editingProduct ? "PUT" : "POST"

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(productData),
      })

      console.log("📡 Statut de la réponse:", response.status)

      if (response.ok) {
        const result = await response.json()
        console.log("✅ Produit sauvegardé:", result)

        await loadProducts() // Recharger la liste
        setShowAddDialog(false)
        setEditingProduct(null)
        setFormData({
          name: "",
          price: "",
          description: "",
          size: "",
          category: "",
          stock_quantity: "",
          image_url: "",
        })
        setError(null)
      } else if (response.status === 401) {
        setError("Session expirée. Veuillez vous reconnecter.")
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Erreur inconnue" }))
        setError(`Erreur ${response.status}: ${errorData.detail || "Impossible de sauvegarder le produit"}`)
        console.error("❌ Erreur sauvegarde:", errorData)
      }
    } catch (error) {
      console.error("❌ Erreur sauvegarde produit:", error)
      setError("Erreur de connexion. Vérifiez que le serveur est démarré.")
    }
    setSubmitting(false)
  }

  const handleEdit = (product: Product) => {
    setEditingProduct(product)
    setFormData({
      name: product.name,
      price: product.price.toString(),
      description: product.description || "",
      size: product.size || "",
      category: product.category || "",
      stock_quantity: product.stock_quantity.toString(),
      image_url: product.image_url || "",
    })
    setError(null)
    setShowAddDialog(true)
  }

  const handleDelete = async (productId: number | string) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce produit ?")) return

    try {
      setError(null)
      const token = localStorage.getItem("token")

      if (!token) {
        setError("Token manquant. Veuillez vous reconnecter.")
        return
      }

      const response = await fetch(`http://localhost:8000/products/${productId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        console.log("✅ Produit supprimé")
        await loadProducts()
      } else if (response.status === 401) {
        setError("Session expirée. Veuillez vous reconnecter.")
      } else {
        const errorData = await response.json().catch(() => ({ detail: "Erreur inconnue" }))
        setError(`Erreur ${response.status}: ${errorData.detail || "Impossible de supprimer le produit"}`)
      }
    } catch (error) {
      console.error("❌ Erreur suppression produit:", error)
      setError("Erreur de connexion. Vérifiez que le serveur est démarré.")
    }
  }

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category?.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusColor = (isActive: boolean) => {
    return isActive ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <div>Chargement des produits...</div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">Gestion des Produits TJRIA</CardTitle>
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button
                className="bg-blue-600 hover:bg-blue-700"
                onClick={() => {
                  setEditingProduct(null)
                  setFormData({
                    name: "",
                    price: "",
                    description: "",
                    size: "",
                    category: "",
                    stock_quantity: "",
                    image_url: "",
                  })
                  setError(null)
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Ajouter un produit
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduct ? "Modifier le produit" : "Ajouter un produit"}</DialogTitle>
              </DialogHeader>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">Nom du produit *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    placeholder="Ex: T-shirt TJRIA"
                  />
                </div>
                <div>
                  <Label htmlFor="price">Prix (DH) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    required
                    placeholder="Ex: 150.00"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                    placeholder="Description du produit..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="size">Taille</Label>
                    <Input
                      id="size"
                      value={formData.size}
                      onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                      placeholder="Ex: M, L, XL"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Catégorie</Label>
                    <Input
                      id="category"
                      value={formData.category}
                      onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                      placeholder="Ex: Vêtements"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="stock">Stock</Label>
                  <Input
                    id="stock"
                    type="number"
                    min="0"
                    value={formData.stock_quantity}
                    onChange={(e) => setFormData({ ...formData, stock_quantity: e.target.value })}
                    placeholder="Ex: 25"
                  />
                </div>
                <div>
                  <Label htmlFor="image">URL de l'image</Label>
                  <Input
                    id="image"
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    placeholder="https://..."
                  />
                </div>
                <div className="flex space-x-2">
                  <Button type="submit" className="flex-1" disabled={submitting}>
                    {submitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        {editingProduct ? "Modification..." : "Ajout..."}
                      </>
                    ) : editingProduct ? (
                      "Modifier"
                    ) : (
                      "Ajouter"
                    )}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)} disabled={submitting}>
                    Annuler
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {error}
                {error.includes("Session expirée") && (
                  <Button
                    variant="link"
                    className="p-0 h-auto ml-2 text-red-600"
                    onClick={() => window.location.reload()}
                  >
                    Se reconnecter
                  </Button>
                )}
              </AlertDescription>
            </Alert>
          )}

          {/* Recherche */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Rechercher des produits..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Tableau des produits */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Produit</TableHead>
                  <TableHead>Prix</TableHead>
                  <TableHead>Catégorie</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredProducts.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={product.image_url || "/placeholder.svg?height=40&width=40"} />
                          <AvatarFallback>{product.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{product.name}</div>
                          <div className="text-sm text-gray-500">{product.size}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{product.price} DH</TableCell>
                    <TableCell>{product.category || "Non définie"}</TableCell>
                    <TableCell>{product.stock_quantity}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(product.is_active)}>
                        {product.is_active ? "Actif" : "Inactif"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(product)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(product.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredProducts.length === 0 && !error && (
            <div className="text-center py-8 text-gray-500">
              {products.length === 0 ? "Aucun produit. Ajoutez votre premier produit !" : "Aucun produit trouvé"}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
